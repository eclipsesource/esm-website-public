/*******************************************************************************
 * Copyright (c) 2007 Innoopract.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0.
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Innoopract - initial API and implementation
 *******************************************************************************/
package calc.ui.rap;

import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.rwt.graphics.Graphics;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import us.mschmidt.komo.CalcEngine;

public class CalcComposite extends Composite {

	private CalcEngine engine = new CalcEngine( 30 );
	
	private Label lblResult;
	
	CalcComposite(Composite parent) {
		super(parent, SWT.NONE );
		
		setLayout( new GridLayout( 5, true ) );
		GridDataFactory fillFactory 
			= GridDataFactory.fillDefaults().span( 5, 1 );
		
		lblResult = new Label( this, SWT.BORDER | SWT.SINGLE );
		lblResult.setText( engine.getDisplayString() );
		lblResult.setAlignment( SWT.RIGHT );
		lblResult.setLayoutData( fillFactory.create() );
		lblResult.setBackground( Graphics.getColor( 248, 247, 197 ) );
		
		createButton( "Del", SWT.COLOR_RED, 1, 'B' );
		createButton( "CE", SWT.COLOR_RED, 2, 'E' );
		createButton( "C", SWT.COLOR_RED, 2, 'C' );

		createButton( "7", SWT.COLOR_BLUE, '7' );
		createButton( "8", SWT.COLOR_BLUE, '8' );
		createButton( "9", SWT.COLOR_BLUE, '9' );
		createButton( "/", SWT.COLOR_RED, '/' );
		createButton( "sqrt", SWT.COLOR_BLUE, 'Q' );

		createButton( "4", SWT.COLOR_BLUE, '4' );
		createButton( "5", SWT.COLOR_BLUE, '5' );
		createButton( "6", SWT.COLOR_BLUE, '6' );
		createButton( "*", SWT.COLOR_RED, '*' );
		createButton( "%", SWT.COLOR_BLUE, '%' );
		
		createButton( "1", SWT.COLOR_BLUE, '1' );
		createButton( "2", SWT.COLOR_BLUE, '2' );
		createButton( "3", SWT.COLOR_BLUE, '3' );
		createButton( "-", SWT.COLOR_RED, '-' );
		createButton( "1/x", SWT.COLOR_BLUE, 'I' );

		createButton( "0", SWT.COLOR_BLUE, '0' );
		createButton( "+/-", SWT.COLOR_BLUE, 'S' );
		createButton( ",", SWT.COLOR_BLUE, '.' );
		createButton( "+", SWT.COLOR_RED, '+' );
		createButton( "=", SWT.COLOR_RED, '=' );
		
		Label message = new Label( this, SWT.NONE );
		message.setText( "Click on the buttons to use." );
		message.setToolTipText( "Calculator 1.0.0.RAP110M2, March 2008" );
		message.setAlignment( SWT.CENTER );
		message.setLayoutData( fillFactory.create() );
	}
	
	private void createButton( final String caption,
			                   final int color, 
			                   final int hspan,
			                   final char keyCode ) {
		Button result = new Button( this, SWT.PUSH | SWT.FLAT | SWT.BORDER );
		result.setText( caption );
		result.setForeground( result.getDisplay().getSystemColor( color ) );
		result.setLayoutData( GridDataFactory.fillDefaults().span( hspan, 1 ).create() );
		result.addSelectionListener( new SelectionAdapter() {
			@Override
			public void widgetSelected( final SelectionEvent evt ) {
				engine.setInput( keyCode );
				lblResult.setText( engine.getDisplayString() );
			}
		} );
	}
	
	private void createButton( final String caption, 
			                   final int color,
			                   final char keyCode ) {
		createButton( caption, color, 1, keyCode );
	}

	
}
