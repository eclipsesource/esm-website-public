/*******************************************************************************
 * Copyright (c) 2007 Innoopract.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0.
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Innoopract - initial API and implementation
 *******************************************************************************/
package calc.ui.rap;

import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.rwt.lifecycle.IEntryPoint;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

/**
 * This class controls all aspects of the application's execution
 * and is contributed through the plugin.xml.
 */
public class CalculatorApplication implements IEntryPoint {

	public int createUI() {
		final Display display = PlatformUI.createDisplay();
		
		final Shell shell = new Shell( display, SWT.NO_TRIM );
		shell.setLayout( new GridLayout( 1, false ) );
		CalcComposite composite = new CalcComposite( shell );
		composite.setLayoutData( GridDataFactory.fillDefaults().align( SWT.CENTER, SWT.CENTER ).grab( true, true ).create() );
		shell.setMaximized( true );
		shell.open();

		runEventLoop( shell );
		
		return PlatformUI.RETURN_OK;
	}

	private void runEventLoop( Shell shell ) {
		Display display = shell.getDisplay();
		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() ) {
				display.sleep();
			}
		}
	}

}