package org.eclipse.rap.swt.designer.demo;

import org.eclipse.rwt.lifecycle.IEntryPoint;

public class EntryPoint implements IEntryPoint {

  public EntryPoint() {
    // TODO Auto-generated constructor stub
  }

  @Override
  public int createUI() {
    ApplicationWindow window = new ApplicationWindow();
    window.open();
    return 0;
  }
}
