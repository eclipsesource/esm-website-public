package org.eclipse.rap.swt.designer.demo;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.ExpandBar;
import org.eclipse.swt.widgets.ExpandItem;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class ApplicationWindow {

  protected Shell shell;
  private Text txtSampleText;
  private Table table;
  private TabItem tabItem2;
  private TabItem tabItem1;
  private TabFolder tabFolder;

  /**
   * Launch the application.
   * 
   * @param args
   */
  public static void main( String[] args ) {
    try {
      ApplicationWindow window = new ApplicationWindow();
      window.open();
    } catch( Exception e ) {
      e.printStackTrace();
    }
  }

  /**
   * Open the window.
   */
  public void open() {
    Display display = Display.getDefault();
    createContents();
    shell.open();
    shell.layout();
    while( !shell.isDisposed() ) {
      if( !display.readAndDispatch() ) {
        display.sleep();
      }
    }
  }

  /**
   * Create contents of the window.
   */
  protected void createContents() {
    shell = new Shell();
    shell.setSize( 655, 440 );
    shell.setText( "SWT Application" );
    shell.setLayout(new GridLayout(1, false));
    
    Group grpTabcontrol = new Group(shell, SWT.NONE);
    grpTabcontrol.setLayout(new GridLayout(1, false));
    grpTabcontrol.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
    grpTabcontrol.setText("TabControl");
    
    Button btnNewButton = new Button(grpTabcontrol, SWT.NONE);
    btnNewButton.addSelectionListener(new SelectionAdapter() {
      @Override
      public void widgetSelected(SelectionEvent e) {
        toggleTabs();
      }
    });
    btnNewButton.setText("New Button");
    
    tabFolder = new TabFolder(shell, SWT.NONE);
    tabFolder.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, true, 1, 1));
    
    tabItem1 = new TabItem(tabFolder, SWT.NONE);
    tabItem1.setText("TabItem 1");
    
    Composite composite = new Composite(tabFolder, SWT.NONE);
    tabItem1.setControl(composite);
    composite.setLayout(new GridLayout(2, false));
    
    Label lblSomeInput = new Label(composite, SWT.NONE);
    lblSomeInput.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
    lblSomeInput.setText("Some input:");
    
    txtSampleText = new Text(composite, SWT.BORDER);
    txtSampleText.setText("Sample Text");
    txtSampleText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
    
    Button btnSampleButton = new Button(composite, SWT.NONE);
    btnSampleButton.setText("Sample Button");
    
    DateTime dateTime = new DateTime(composite, SWT.BORDER);
    
    ExpandBar expandBar = new ExpandBar(composite, SWT.NONE);
    expandBar.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
    
    ExpandItem xpndtmItem = new ExpandItem(expandBar, SWT.NONE);
    xpndtmItem.setExpanded(true);
    xpndtmItem.setText("Item 1");
    
    Composite composite_1 = new Composite(expandBar, SWT.NONE);
    xpndtmItem.setControl(composite_1);
    composite_1.setLayout(new GridLayout(5, false));
    
    Spinner spinner = new Spinner(composite_1, SWT.BORDER);
    new Label(composite_1, SWT.NONE);
    
    Button btnRadioButton = new Button(composite_1, SWT.RADIO);
    btnRadioButton.setText("Radio Button");
    new Label(composite_1, SWT.NONE);
    
    ProgressBar progressBar = new ProgressBar(composite_1, SWT.NONE);
    xpndtmItem.setHeight(xpndtmItem.getControl().computeSize(SWT.DEFAULT, SWT.DEFAULT).y);
    
    ExpandItem xpndtmItem_1 = new ExpandItem(expandBar, SWT.NONE);
    xpndtmItem_1.setText("Item 2");
    new Label(composite, SWT.NONE);
    new Label(composite, SWT.NONE);
    
    tabItem2 = new TabItem(tabFolder, SWT.NONE);
    tabItem2.setText("TabItem 2");
    
    table = new Table(tabFolder, SWT.BORDER | SWT.FULL_SELECTION);
    tabItem2.setControl(table);
    table.setHeaderVisible(true);
    table.setLinesVisible(true);
    
    TableColumn tblclmnColumn = new TableColumn(table, SWT.NONE);
    tblclmnColumn.setWidth(100);
    tblclmnColumn.setText("Column 1");
    
    TableColumn tblclmnColumn_1 = new TableColumn(table, SWT.NONE);
    tblclmnColumn_1.setWidth(100);
    tblclmnColumn_1.setText("Column2");
    
    TableColumn tblclmnColumn_2 = new TableColumn(table, SWT.NONE);
    tblclmnColumn_2.setMoveable(true);
    tblclmnColumn_2.setWidth(300);
    tblclmnColumn_2.setText("Column 3");
  }

  protected void toggleTabs() {
    int selectionIndex = tabFolder.getSelectionIndex();
    if( selectionIndex == tabFolder.indexOf( tabItem1 ) ) {
      tabFolder.setSelection( tabItem2 );
    } else {
      tabFolder.setSelection( tabItem1 );
    }
  }
}
