
package com.eclipsesource.databinding.multivalidation;

import java.util.Date;

import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.core.databinding.validation.MultiValidator;
import org.eclipse.core.databinding.validation.ValidationStatus;
import org.eclipse.core.runtime.IStatus;

public class PeriodValidator extends MultiValidator {

	private final IObservableValue start;

	private final IObservableValue end;

	public PeriodValidator(final IObservableValue start, final IObservableValue end) {
		this.start = start;
		this.end = end;
	}

	@Override
	protected IStatus validate() {
		Date startDate = (Date) this.start.getValue();
		Date endDate = (Date) this.end.getValue();
		IStatus status = ValidationStatus.ok();

		if ((this.start != null) && (this.end != null)) {
			if (startDate.after(endDate)) {
				status = ValidationStatus.error("The start date has to be before the end date.");
			}
		}
		return status;
	}

}
