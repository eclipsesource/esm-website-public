
package com.eclipsesource.databinding.multivalidation;

import java.util.Date;

import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.UpdateValueStrategy;
import org.eclipse.core.databinding.beans.BeansObservables;
import org.eclipse.core.databinding.conversion.Converter;
import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class MultiValidation {

	private DateTime dateTimeStart;

	private DateTime dateTimeEnd;

	private Label status;

	private final Period period;

	public MultiValidation() {
		this.period = new Period(new Date(), new Date());
	}

	public void createContent(final Composite parent) {
		GridLayout layout = new GridLayout(4, false);
		layout.marginWidth = 10;
		layout.marginHeight = 10;
		parent.setLayout(layout);

		Label label2 = new Label(parent, SWT.NONE);
		label2.setLayoutData(new GridData(SWT.BEGINNING, SWT.CENTER, false, false));
		label2.setText("From:");

		this.dateTimeStart = new DateTime(parent, SWT.DATE | SWT.MEDIUM);
		this.dateTimeStart.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false));

		Label label3 = new Label(parent, SWT.NONE);
		label3.setLayoutData(new GridData(SWT.BEGINNING, SWT.CENTER, false, false));
		label3.setText("To:");

		this.dateTimeEnd = new DateTime(parent, SWT.DATE | SWT.MEDIUM);
		this.dateTimeEnd.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false));

		Label label1 = new Label(parent, SWT.NONE);
		label1.setLayoutData(new GridData(SWT.BEGINNING, SWT.TOP, false, false));
		label1.setText("Status:");

		this.status = new Label(parent, SWT.NONE);
		this.status.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 3, 0));
	}

	private void createDatabinding() {

		DateTimeObservableValue startObservable = new DateTimeObservableValue(this.dateTimeStart);
		DateTimeObservableValue endObservable = new DateTimeObservableValue(this.dateTimeEnd);

		DataBindingContext context = new DataBindingContext();

		// bind start and end
		UpdateValueStrategy modelToTarget = new UpdateValueStrategy(
				UpdateValueStrategy.POLICY_UPDATE);
		UpdateValueStrategy targetToModel = new UpdateValueStrategy(
				UpdateValueStrategy.POLICY_UPDATE);

		context.bindValue(startObservable, BeansObservables.observeValue(this.period,
				Period.PROP_START), targetToModel, modelToTarget);

		context.bindValue(endObservable, BeansObservables
				.observeValue(this.period, Period.PROP_END), targetToModel, modelToTarget);

		// bind status
		PeriodValidator periodValidator = new PeriodValidator(startObservable, endObservable);

		modelToTarget = new UpdateValueStrategy(UpdateValueStrategy.POLICY_UPDATE);
		modelToTarget.setConverter(new Converter(IStatus.class, String.class) {

			@Override
			public Object convert(final Object arg) {
				if (arg instanceof IStatus) {
					IStatus status = (IStatus) arg;
					return status.getMessage();
				}
				return null;
			}

		});
		targetToModel = new UpdateValueStrategy(UpdateValueStrategy.POLICY_UPDATE);

		context.bindValue(SWTObservables.observeText(this.status), periodValidator
				.getValidationStatus(), targetToModel, modelToTarget);
	}

	public static void main(final String[] args) {
		final Display display = new Display();

		Realm.runWithDefault(SWTObservables.getRealm(display), new Runnable() {

			public void run() {
				// create and open main application window
				Shell shell = new Shell(display);

				MultiValidation multiValidation = new MultiValidation();
				multiValidation.createContent(shell);
				multiValidation.createDatabinding();

				shell.setText("Cross Validation");
				shell.pack();
				shell.open();
				while (!shell.isDisposed()) {
					if (!display.readAndDispatch()) {
						display.sleep();
					}
				}

				display.dispose();
			}
		});

	}

}
