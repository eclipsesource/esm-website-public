package com.eclipsesource.samples;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.eclipsesource.ui.partblockmonitor.internal.IResponsiveRunner;
import com.eclipsesource.ui.partblockmonitor.internal.NiftyProgress;
import com.eclipsesource.ui.partblockmonitor.internal.TransparentUIBlocker;

public class View extends ViewPart {

  public static final String ID = "com.eclipsesource.samples.view";
  private TableViewer viewer;
 
  class ViewLabelProvider extends LabelProvider implements ITableLabelProvider {

    public String getColumnText( Object obj, int index ) {
      return getText( obj );
    }

    public Image getColumnImage( Object obj, int index ) {
      return getImage( obj );
    }

    public Image getImage( Object obj ) {
      return PlatformUI.getWorkbench()
        .getSharedImages()
        .getImage( ISharedImages.IMG_OBJ_ELEMENT );
    }
  }

  /**
   * This is a callback that will allow us to create the viewer and initialize
   * it.
   */
  public void createPartControl( final Composite parent ) {
    viewer = new TableViewer( parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL );
    viewer.setContentProvider( new ArrayContentProvider() );
    viewer.setLabelProvider( new ViewLabelProvider() );
    viewer.setInput( new String[] { "One", "Two", "Three" } );
    viewer.addSelectionChangedListener( new ISelectionChangedListener() {
      public void selectionChanged( SelectionChangedEvent event ) {
        new NiftyProgress(
        new IResponsiveRunner() {
          
          public void runOutsideUIThread( final IProgressMonitor monitor ) {
            try {
              monitor.beginTask( "my task", 40 );
              for( int i = 0; i < 40 && !monitor.isCanceled(); i++ ) {
                Thread.sleep( 100 );
                monitor.worked( 1 );
                monitor.setTaskName( "task number " + i );
              }
              monitor.done();
            } catch( InterruptedException e ) {
              e.printStackTrace();
            }
          }
          
          public void handleException( Exception caught ) {
          }
          
          public void uiFeedbackAfterRun() {
            if ( !viewer.getTable().isDisposed() ) {
              viewer.setInput( new String[] { "One", "Two", "Three", "Four" } );
            }
          }
          
        }, new TransparentUIBlocker( parent, true ) ).run();
      }
    });
  }

  /**
   * Passing the focus request to the viewer's control.
   */
  public void setFocus() {
    viewer.getControl().setFocus();
  }
}