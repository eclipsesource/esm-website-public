/******************************************************************************* 
* Copyright (c) 2009 EclipseSource and others. All rights reserved. This
* program and the accompanying materials are made available under the terms of
* the Eclipse Public License v1.0 which accompanies this distribution, and is
* available at http://www.eclipse.org/legal/epl-v10.html
*
* Contributors:
*   EclipseSource - initial API and implementation
******************************************************************************/
package org.example.publisher;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;


import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.equinox.internal.p2.artifact.repository.ArtifactRepositoryManager;
import org.eclipse.equinox.internal.p2.metadata.repository.MetadataRepositoryManager;
import org.eclipse.equinox.internal.provisional.p2.artifact.repository.IArtifactRepository;
import org.eclipse.equinox.internal.provisional.p2.core.ProvisionException;
import org.eclipse.equinox.internal.provisional.p2.metadata.repository.IMetadataRepository;
import org.eclipse.equinox.internal.provisional.spi.p2.artifact.repository.SimpleArtifactRepositoryFactory;
import org.eclipse.equinox.internal.provisional.spi.p2.metadata.repository.SimpleMetadataRepositoryFactory;
import org.eclipse.equinox.p2.publisher.IPublisherAction;
import org.eclipse.equinox.p2.publisher.IPublisherInfo;
import org.eclipse.equinox.p2.publisher.Publisher;
import org.eclipse.equinox.p2.publisher.PublisherInfo;
import org.eclipse.equinox.p2.publisher.eclipse.BundlesAction;

/**
 * This simple publisher example demonstrates how to use the publisher
 * API to publish a list of bundles.
 * @throws URISyntaxException 
 * @throws ProvisionException 
 */
public class PublisherExample implements IApplication {

	public static String BUNDLE_LOCATION = "/home/mybundles"; // Set this to the location of your bundles
	public static String ARTIFACT_REPOSITORY = "file:/artifact_repo"; // Set this to your artifact repository
	public static String METADATA_REPOSITORY = "file:/metadata_repo"; // Set this to your metadata repository
	
	public Object start(IApplicationContext context) throws Exception {
		IPublisherInfo info = createPublisherInfo();
		IPublisherAction[] actions = createActions();
		Publisher publisher = new Publisher(info);
		publisher.publish(actions, new NullProgressMonitor());
		return null;
	}

	public void stop() {
	}

	public IPublisherInfo createPublisherInfo() throws ProvisionException, URISyntaxException {
		PublisherInfo result = new PublisherInfo();
		
		// Create the metadata repository.  This will fail if a repository already exists here
		IMetadataRepository metadataRepository = new SimpleMetadataRepositoryFactory().create(new URI(METADATA_REPOSITORY), "Sample Metadata Repository", MetadataRepositoryManager.TYPE_SIMPLE_REPOSITORY, Collections.EMPTY_MAP);
		
		// Create the artifact repository.  This will fail if a repository already exists here
		IArtifactRepository artifactRepository = new SimpleArtifactRepositoryFactory().create(new URI(ARTIFACT_REPOSITORY), "Sample Artifact Repository", ArtifactRepositoryManager.TYPE_SIMPLE_REPOSITORY, Collections.EMPTY_MAP);
		
		result.setMetadataRepository(metadataRepository);
		result.setArtifactRepository(artifactRepository);
		result.setArtifactOptions(IPublisherInfo.A_PUBLISH | IPublisherInfo.A_INDEX);
		return result;
	}
	
	public IPublisherAction[] createActions() {
		IPublisherAction[] result = new IPublisherAction[1];
		File[] bundleLocations = new File[1];
		bundleLocations[0] =  new File(BUNDLE_LOCATION);
		BundlesAction bundlesAction = new BundlesAction(bundleLocations);
		result[0] = bundlesAction;
		return result;
	}
}
